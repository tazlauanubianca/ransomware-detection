sudo apt-get install vlc
vlc 
