sudo snap install notepad-plus-plus
notepad-plus-plus
