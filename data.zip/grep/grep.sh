grep -r "Hello World" .
grep -r "Great" ~/Desktop
