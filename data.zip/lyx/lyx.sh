sudo apt-get remove lyx
lyx
